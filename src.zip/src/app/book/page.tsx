"use client";
import { useState, useEffect } from "react";
import { DayPicker } from "react-day-picker";
import "react-day-picker/dist/style.css";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { Calendar, Clock, Heart, Car, Users, DollarSign, MapPin, Mail, User, FileText, MessageSquare } from "lucide-react";

export default function BookingForm() {
  const [dates, setDates] = useState<Date[]>([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [instructions, setInstructions] = useState("");
  const [notes, setNotes] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [catCount, setCatCount] = useState(1);
  const [isClient, setIsClient] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const searchParams = useSearchParams();

  // Service pricing configuration
  const servicePricing = {
    "Standard Visit": { basePrice: 25, duration: "30 minutes" },
    "Extended Visit": { basePrice: 35, duration: "45 minutes" },
    "Vet Appointment": { basePrice: 75, duration: "Transport & Care" }
  };

  // Calculate total price including cat count
  const calculatePrice = () => {
    if (!selectedService || !servicePricing[selectedService as keyof typeof servicePricing]) return 0;
    const basePrice = servicePricing[selectedService as keyof typeof servicePricing].basePrice;
    const additionalCats = Math.max(0, catCount - 2);
    const additionalCost = additionalCats * 5;
    return basePrice + additionalCost;
  };

  const totalPrice = calculatePrice();
  const additionalCats = Math.max(0, catCount - 2);
  const additionalCost = additionalCats * 5;

  // Prevent hydration mismatch by only rendering form after client-side hydration
  useEffect(() => {
    setIsClient(true);
    
    // Get service from URL parameter
    const serviceFromUrl = searchParams.get('service');
    if (serviceFromUrl) {
      setSelectedService(serviceFromUrl);
    }
  }, [searchParams]);

  const services = [
    "Standard Visit",
    "Extended Visit", 
    "Vet Appointment"
  ];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          address,
          instructions,
          dates: dates.map((d) => d.toISOString().split("T")[0]),
          notes,
          service: selectedService,
          catCount,
          totalPrice,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(`❌ ${data.error || "Failed to submit booking"}`);
        return;
      }

      alert("✅ Booking request sent! We'll get back to you soon.");
      setName("");
      setEmail("");
      setAddress("");
      setInstructions("");
      setDates([]);
      setNotes("");
      setSelectedService("");
      setCatCount(1);
    } catch (err) {
      console.error("Error creating booking:", err);
      alert("❌ Something went wrong. Try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  // 📌 Helpers
  function selectWeek() {
    const today = new Date();
    const week: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      week.push(d);
    }
    setDates(week);
  }

  function selectMonth() {
    const today = new Date();
    const month: Date[] = [];
    const year = today.getFullYear();
    const monthIndex = today.getMonth();
    const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

    for (let i = today.getDate(); i <= daysInMonth; i++) {
      month.push(new Date(year, monthIndex, i));
    }
    setDates(month);
  }

  function clearDates() {
    setDates([]);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-beige-50 to-olive-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {isClient ? (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Header */}
            <div className="text-center mb-12">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="w-20 h-20 bg-gradient-to-br from-olive-100 to-warm-brown-100 rounded-full flex items-center justify-center mx-auto mb-6"
              >
                <Calendar size={32} className="text-olive-600" />
              </motion.div>
              <h1 className="text-4xl lg:text-5xl font-serif font-bold text-warm-brown-800 mb-4">
                Book Your Cat Sitting
              </h1>
              <p className="text-xl text-dark-gray-600 max-w-2xl mx-auto">
                Let's create a personalized care plan for your feline friends. Fill out the form below and we'll get back to you within 24 hours.
              </p>
              <div className="w-24 h-1 bg-olive-500 mx-auto rounded-full mt-6"></div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Information Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="bg-white rounded-3xl p-8 shadow-soft"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-olive-100 rounded-full flex items-center justify-center">
                    <User size={20} className="text-olive-600" />
                  </div>
                  <h2 className="text-2xl font-serif font-semibold text-warm-brown-800">Personal Information</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="w-full px-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full px-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50"
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>

                <div className="mt-6">
                  <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                    Home Address *
                  </label>
                  <div className="relative">
                    <MapPin size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-dark-gray-400" />
                    <input
                      type="text"
                      placeholder="123 Main St, Unit #, Ottawa, ON"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      required
                      className="w-full pl-12 pr-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50"
                    />
                  </div>
                </div>
              </motion.div>

              {/* Service Selection Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="bg-white rounded-3xl p-8 shadow-soft"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-warm-brown-100 rounded-full flex items-center justify-center">
                    <Clock size={20} className="text-warm-brown-600" />
                  </div>
                  <h2 className="text-2xl font-serif font-semibold text-warm-brown-800">Service Details</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                      Service Type *
                    </label>
                    <select 
                      value={selectedService} 
                      onChange={(e) => setSelectedService(e.target.value)}
                      required
                      className="w-full px-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50"
                    >
                      <option value="">Select a service...</option>
                      {services.map((service) => (
                        <option key={service} value={service}>
                          {service} - ${servicePricing[service as keyof typeof servicePricing]?.basePrice}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                      Number of Cats *
                    </label>
                    <div className="relative">
                      <Users size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-dark-gray-400" />
                      <select
                        value={catCount}
                        onChange={(e) => setCatCount(Number(e.target.value))}
                        required
                        className="w-full pl-12 pr-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                          <option key={num} value={num}>
                            {num} {num === 1 ? 'cat' : 'cats'}
                          </option>
                        ))}
                      </select>
                    </div>
                    {additionalCats > 0 && (
                      <p className="text-sm text-olive-600 mt-2">
                        +${additionalCost} for {additionalCats} additional cat{additionalCats > 1 ? 's' : ''}
                      </p>
                    )}
                  </div>
                </div>

                {/* Price Display */}
                {selectedService && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4 }}
                    className="mt-6 bg-gradient-to-r from-olive-50 to-warm-brown-50 rounded-2xl p-6 border border-olive-200"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-warm-brown-800 mb-1">
                          {selectedService}
                        </h3>
                        <p className="text-dark-gray-600">
                          {servicePricing[selectedService as keyof typeof servicePricing]?.duration} • {catCount} cat{catCount > 1 ? 's' : ''}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-warm-brown-700">
                          ${totalPrice}
                        </div>
                        <div className="text-sm text-dark-gray-500">per visit</div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>

              {/* Date Selection Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="bg-white rounded-3xl p-8 shadow-soft"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-olive-100 rounded-full flex items-center justify-center">
                    <Calendar size={20} className="text-olive-600" />
                  </div>
                  <h2 className="text-2xl font-serif font-semibold text-warm-brown-800">Select Dates</h2>
                </div>

                <div className="grid lg:grid-cols-2 gap-8">
                  <div>
                    <DayPicker
                      mode="multiple"
                      selected={dates}
                      onSelect={(newDates) => setDates(newDates || [])}
                      fromDate={new Date()}
                      className="border border-beige-300 rounded-2xl p-4 bg-beige-50"
                    />

                    {/* Quick Select Buttons */}
                    <div className="mt-6 space-y-3">
                      <button
                        type="button"
                        onClick={selectWeek}
                        className="w-full py-3 px-4 bg-olive-100 hover:bg-olive-200 text-olive-700 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105"
                      >
                        📆 Select This Week
                      </button>
                      <button
                        type="button"
                        onClick={selectMonth}
                        className="w-full py-3 px-4 bg-warm-brown-100 hover:bg-warm-brown-200 text-warm-brown-700 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105"
                      >
                        🗓 Select Rest of Month
                      </button>
                      <button
                        type="button"
                        onClick={clearDates}
                        className="w-full py-3 px-4 bg-beige-200 hover:bg-beige-300 text-dark-gray-700 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105"
                      >
                        🔄 Clear All Dates
                      </button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-warm-brown-800 mb-4">Selected Dates</h3>
                    {dates.length === 0 ? (
                      <div className="text-center py-8 text-dark-gray-500">
                        <Calendar size={48} className="mx-auto mb-4 text-beige-400" />
                        <p>No dates selected yet</p>
                        <p className="text-sm">Click on the calendar to select your preferred dates</p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {dates.map((d) => (
                          <motion.div
                            key={d.toISOString()}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex items-center justify-between p-3 bg-beige-50 rounded-xl border border-beige-200"
                          >
                            <span className="text-dark-gray-700 font-medium">
                              {d.toLocaleDateString('en-US', { 
                                weekday: 'long', 
                                year: 'numeric', 
                                month: 'long', 
                                day: 'numeric' 
                              })}
                            </span>
                            <button
                              type="button"
                              onClick={() => setDates(dates.filter((day) => day.getTime() !== d.getTime()))}
                              className="text-red-500 hover:text-red-700 transition-colors duration-300"
                            >
                              ❌
                            </button>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>

              {/* Additional Information Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="bg-white rounded-3xl p-8 shadow-soft"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-10 h-10 bg-warm-brown-100 rounded-full flex items-center justify-center">
                    <FileText size={20} className="text-warm-brown-600" />
                  </div>
                  <h2 className="text-2xl font-serif font-semibold text-warm-brown-800">Additional Information</h2>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                      Entrance Instructions
                    </label>
                    <textarea
                      placeholder="e.g., side door code, buzzer #, key location, building access instructions"
                      value={instructions}
                      onChange={(e) => setInstructions(e.target.value)}
                      rows={3}
                      className="w-full px-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50 resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-dark-gray-700 mb-2">
                      Additional Notes
                    </label>
                    <textarea
                      placeholder="Anything else we should know about your cat(s), special care instructions, medical conditions, etc."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-3 border border-beige-300 rounded-2xl focus:ring-2 focus:ring-olive-500 focus:border-transparent transition-all duration-300 bg-beige-50 resize-none"
                    />
                  </div>
                </div>
              </motion.div>

              {/* Submit Button */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.7 }}
                className="text-center"
              >
                <button
                  type="submit"
                  disabled={isSubmitting || dates.length === 0}
                  className={`px-12 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 ${
                    isSubmitting || dates.length === 0
                      ? 'bg-dark-gray-300 text-dark-gray-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-olive-600 to-warm-brown-600 hover:from-olive-700 hover:to-warm-brown-700 text-white shadow-medium hover:shadow-large'
                  }`}
                >
                  {isSubmitting ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Submitting...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <MessageSquare size={20} />
                      <span>Send Booking Request</span>
                    </div>
                  )}
                </button>
                
                {dates.length === 0 && (
                  <p className="text-sm text-dark-gray-500 mt-3">
                    Please select at least one date to continue
                  </p>
                )}
              </motion.div>
            </form>
          </motion.div>
        ) : (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-gradient-to-br from-olive-100 to-warm-brown-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <Calendar size={32} className="text-olive-600" />
            </div>
            <p className="text-xl text-dark-gray-600">Loading booking form...</p>
          </div>
        )}
      </div>
    </div>
  );
}
