'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { CheckCircle, Calendar, Clock, DollarSign } from 'lucide-react';

interface Booking {
  _id: string;
  name: string;
  dates: string[];
  notes: string;
  deposit: {
    amount: number;
    total: number;
    status: string;
    paidAt: string;
  };
}

export default function SuccessPage() {
  const searchParams = useSearchParams();
  const bookingId = searchParams.get('bookingId');
  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (bookingId) {
      fetchBookingDetails();
    }
  }, [bookingId]);

  const fetchBookingDetails = async () => {
    try {
      const response = await fetch(`/api/bookings/${bookingId}`);
      if (response.ok) {
        const data = await response.json();
        setBooking(data);
      }
    } catch (error) {
      console.error('Error fetching booking:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading your booking details...</p>
        </div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Booking Not Found</h1>
          <p className="text-gray-600 mb-6">We couldn't find your booking details.</p>
          <Link 
            href="/" 
            className="bg-pink-500 text-white px-6 py-3 rounded-lg hover:bg-pink-600 transition-colors"
          >
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Payment Successful! 🎉
          </h1>
          <p className="text-lg text-gray-600">
            Your deposit has been received and your booking is confirmed.
          </p>
        </div>

        {/* Booking Details Card */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-pink-500" />
            Booking Details
          </h2>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Client Name:</span>
              <span className="font-medium text-gray-800">{booking.name}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Service Dates:</span>
              <span className="font-medium text-gray-800">
                {booking.dates.map(date => new Date(date).toLocaleDateString()).join(', ')}
              </span>
            </div>
            
            {booking.notes && (
              <div className="flex justify-between items-start py-2 border-b border-gray-100">
                <span className="text-gray-600">Special Notes:</span>
                <span className="font-medium text-gray-800 text-right max-w-xs">{booking.notes}</span>
              </div>
            )}
          </div>
        </div>

        {/* Payment Details Card */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <DollarSign className="w-5 h-5 mr-2 text-green-500" />
            Payment Summary
          </h2>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Deposit Paid (50%):</span>
              <span className="font-medium text-green-600">${booking.deposit.amount}</span>
            </div>
            
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Total Service Cost:</span>
              <span className="font-medium text-gray-800">${booking.deposit.total}</span>
            </div>
            
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-600">Remaining Balance:</span>
              <span className="font-medium text-pink-600">
                ${(booking.deposit.total - booking.deposit.amount).toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Next Steps Card */}
        <div className="bg-blue-50 rounded-xl p-6 mb-8">
          <h2 className="text-xl font-semibold text-blue-800 mb-4 flex items-center">
            <Clock className="w-5 h-5 mr-2 text-blue-500" />
            What Happens Next?
          </h2>
          
          <div className="space-y-3 text-blue-700">
            <p>✅ Your booking is now confirmed and secured</p>
            <p>📧 You'll receive a confirmation email shortly</p>
            <p>🐱 We'll contact you before your service date</p>
            <p>💳 The remaining balance will be collected when service begins</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <Link 
            href="/" 
            className="inline-block bg-pink-500 text-white px-8 py-3 rounded-lg hover:bg-pink-600 transition-colors font-medium"
          >
            Return to Home
          </Link>
          
          <p className="text-sm text-gray-500">
            Need help? Contact us at{' '}
            <a href="mailto:support@catsitting.com" className="text-pink-500 hover:underline">
              support@catsitting.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
