import { NextResponse } from "next/server";
import clientPromise from "@/lib/mongodb";

export async function GET(req: Request) {
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const page = parseInt(url.searchParams.get("page") || "1", 10);
    const limit = parseInt(url.searchParams.get("limit") || "10", 10);

    const client = await clientPromise;
    const db = client.db("catsitting");

    const collection = db.collection("messages");

    const totalCount = await collection.countDocuments();
    const totalPages = Math.ceil(totalCount / limit);

    const messages = await collection
      .find()
      .sort({ status: 1, createdAt: -1 }) // unread first, newest first
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray();

    return NextResponse.json({
      messages,
      page,
      totalPages,
      totalCount,
    });
  } catch (err) {
    console.error("Error fetching messages:", err);
    return NextResponse.json(
      { error: "Failed to fetch messages" },
      { status: 500 }
    );
  }
}
