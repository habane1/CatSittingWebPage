import { NextResponse } from "next/server";
import clientPromise from "@/lib/mongodb";
import { ObjectId } from "mongodb";
import { sendEmail } from "@/lib/mailer";

export async function POST(req: Request) {
  // Protect route
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const client = await clientPromise;
    const db = client.db("catsitting");

    const now = new Date();
    const fortyEightHoursAgo = new Date(now.getTime() - (48 * 60 * 60 * 1000));

    // Find bookings with pending deposits that have expired
    const expiredBookings = await db.collection("bookings").find({
      status: "approved",
      "deposit.status": "pending",
      "deposit.deadline": { $lt: now }
    }).toArray();

    if (expiredBookings.length === 0) {
      return NextResponse.json({ 
        message: "No expired deposits found",
        expiredCount: 0 
      });
    }

    const cancelledBookings = [];

    for (const booking of expiredBookings) {
      // Update booking status to cancelled
      await db.collection("bookings").updateOne(
        { _id: booking._id },
        { 
          $set: { 
            status: "cancelled",
            "deposit.status": "expired",
            cancelledAt: now,
            cancellationReason: "Deposit payment expired after 48 hours"
          } 
        }
      );

      // Send cancellation email to client
      try {
        const emailSubject = "❌ Your Cat Sitting Booking Has Been Cancelled";
        const emailText = `Hi ${booking.name},

Unfortunately, your cat sitting booking has been automatically cancelled because the 50% deposit payment was not completed within the required 48-hour window.

Booking Details:
- Service: Cat Sitting
- Dates: ${Array.isArray(booking.dates) ? booking.dates.map(d => new Date(d).toLocaleDateString()).join(", ") : "To be confirmed"}
- Notes: ${booking.notes || "None"}

If you would like to rebook, please visit our website and submit a new booking request.

We apologize for any inconvenience this may cause.

Best regards,
The Cat Sitting Team`;

        const emailHtml = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #dc2626;">❌ Your Cat Sitting Booking Has Been Cancelled</h2>
            <p>Hi ${booking.name},</p>
            <p>Unfortunately, your cat sitting booking has been automatically cancelled because the 50% deposit payment was not completed within the required 48-hour window.</p>
            
            <div style="background-color: #fef2f2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #dc2626;">
              <h3 style="color: #374151; margin-top: 0;">Cancelled Booking Details:</h3>
              <p><strong>Service:</strong> Cat Sitting</p>
              <p><strong>Dates:</strong> ${Array.isArray(booking.dates) ? booking.dates.map(d => new Date(d).toLocaleDateString()).join(", ") : "To be confirmed"}</p>
              <p><strong>Notes:</strong> ${booking.notes || "None"}</p>
            </div>

            <p>If you would like to rebook, please visit our website and submit a new booking request.</p>
            
            <p>We apologize for any inconvenience this may cause.</p>
            <p><strong>Best regards,<br>The Cat Sitting Team</strong></p>
          </div>
        `;

        await sendEmail(booking.email, emailSubject, emailText, emailHtml);
      } catch (emailError) {
        console.error(`❌ Error sending cancellation email for booking ${booking._id}:`, emailError);
      }

      cancelledBookings.push({
        id: booking._id,
        name: booking.name,
        email: booking.email,
        dates: booking.dates
      });
    }

    return NextResponse.json({ 
      message: `Successfully cancelled ${cancelledBookings.length} expired bookings`,
      expiredCount: expiredBookings.length,
      cancelledBookings 
    });

  } catch (err) {
    console.error("❌ Error checking expired deposits:", err);
    return NextResponse.json(
      { error: "Failed to check expired deposits" },
      { status: 500 }
    );
  }
}

// GET endpoint to view expired deposits without cancelling them
export async function GET(req: Request) {
  // Protect route
  const auth = req.headers.get("authorization");
  if (auth !== `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const client = await clientPromise;
    const db = client.db("catsitting");

    const now = new Date();
    const fortyEightHoursAgo = new Date(now.getTime() - (48 * 60 * 60 * 1000));

    // Find bookings with pending deposits that have expired or are close to expiring
    const expiredBookings = await db.collection("bookings").find({
      status: "approved",
      "deposit.status": "pending",
      "deposit.deadline": { $lt: now }
    }).toArray();

    const expiringSoonBookings = await db.collection("bookings").find({
      status: "approved",
      "deposit.status": "pending",
      "deposit.deadline": { 
        $gte: now, 
        $lte: new Date(now.getTime() + (2 * 60 * 60 * 1000)) // Within next 2 hours
      }
    }).toArray();

    return NextResponse.json({
      expired: expiredBookings.map(booking => ({
        id: booking._id,
        name: booking.name,
        email: booking.email,
        dates: booking.dates,
        deadline: booking.deposit.deadline,
        timeUntilExpiry: Math.floor((now.getTime() - new Date(booking.deposit.deadline).getTime()) / (1000 * 60 * 60)) // hours
      })),
      expiringSoon: expiringSoonBookings.map(booking => ({
        id: booking._id,
        name: booking.name,
        email: booking.email,
        dates: booking.dates,
        deadline: booking.deposit.deadline,
        timeUntilExpiry: Math.floor((new Date(booking.deposit.deadline).getTime() - now.getTime()) / (1000 * 60 * 60)) // hours
      }))
    });

  } catch (err) {
    console.error("❌ Error fetching expired deposits:", err);
    return NextResponse.json(
      { error: "Failed to fetch expired deposits" },
      { status: 500 }
    );
  }
}
