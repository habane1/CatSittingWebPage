import { NextResponse } from "next/server";
import { ObjectId } from "mongodb";
import clientPromise from "@/lib/mongodb";
import { sendEmail } from "@/lib/mailer";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;

    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const client = await clientPromise;
    const db = client.db("catsitting");

    const booking = await db.collection("bookings").findOne({ _id: new ObjectId(id) });

    if (!booking) {
      return NextResponse.json({ error: "Booking not found" }, { status: 404 });
    }

    return NextResponse.json(booking);
  } catch (error) {
    console.error("❌ Error fetching booking:", error);
    return NextResponse.json({ error: "Failed to fetch booking" }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const { status, dates, notes } = await req.json();

    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const client = await clientPromise;
    const db = client.db("catsitting");

    // Get the current booking
    const currentBooking = await db.collection("bookings").findOne({ _id: new ObjectId(id) });
    const isStatusChangeToApproved =
      status && status === "approved" && currentBooking?.status !== "approved";

    const update: any = {};
    if (status) update.status = status;
    if (Array.isArray(dates)) update.dates = dates;
    if (typeof notes === "string") update.notes = notes;

    const result = await db
      .collection("bookings")
      .updateOne({ _id: new ObjectId(id) }, { $set: update });

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Booking not found" }, { status: 404 });
    }

    // Send approval email if status is changed to approved
    if (isStatusChangeToApproved && currentBooking) {
      // Email content - defined outside try block so catch can access it
      const emailSubject = "🎉 Your Cat Sitting Booking Has Been Approved!";
      
      try {
        // ✅ Call deposit API to get Stripe Checkout link
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
        console.log(`🔗 Using base URL: ${baseUrl}`);
        
        console.log(`🔗 Calling deposit API at: ${baseUrl}/api/payments/deposit`);
        const depositRes = await fetch(
          `${baseUrl}/api/payments/deposit`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ bookingId: id }),
          }
        );
        
        if (!depositRes.ok) {
          throw new Error(`Deposit API failed: ${depositRes.status} ${depositRes.statusText}`);
        }
        
        const depositData = await depositRes.json();
        const depositUrl = depositData?.url;
        
        if (!depositUrl) {
          throw new Error('No deposit URL received from API');
        }
        
        console.log(`✅ Deposit URL received: ${depositUrl}`);

        const emailText = `Hi ${currentBooking.name},

Great news! Your cat sitting booking has been approved.

Booking Details:
- Service: Cat Sitting
- Dates: ${
          Array.isArray(currentBooking.dates) && currentBooking.dates.length > 0
            ? currentBooking.dates
                .map((d: string) => new Date(d).toLocaleDateString())
                .join(", ")
            : currentBooking.date
            ? new Date(currentBooking.date).toLocaleDateString()
            : "To be confirmed"
        }
- Notes: ${currentBooking.notes || "None"}

👉 Please complete your 50% deposit here to confirm your booking:
${depositUrl || "Link unavailable"}

Thank you for choosing our cat sitting service!

Best regards,
The Cat Sitting Team`;

        const emailHtml = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #ec4899;">🎉 Your Cat Sitting Booking Has Been Approved!</h2>
            <p>Hi ${currentBooking.name},</p>
            <p>Great news! Your cat sitting booking has been approved.</p>
            
            <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #374151; margin-top: 0;">Booking Details:</h3>
              <p><strong>Service:</strong> Cat Sitting</p>
              <p><strong>Dates:</strong> ${
                Array.isArray(currentBooking.dates) && currentBooking.dates.length > 0
                  ? currentBooking.dates
                      .map((d: string) => new Date(d).toLocaleDateString())
                      .join(", ")
                  : currentBooking.date
                  ? new Date(currentBooking.date).toLocaleDateString()
                  : "To be confirmed"
              }</p>
              <p><strong>Notes:</strong> ${currentBooking.notes || "None"}</p>
            </div>

            <p>👉 <a href="${depositUrl}" style="background-color:#ec4899; color:white; padding:10px 20px; text-decoration:none; border-radius:6px;">Pay 50% Deposit</a></p>
            
            <p>Thank you for choosing our cat sitting service!</p>
            <p><strong>Best regards,<br>The Cat Sitting Team</strong></p>
          </div>
        `;

        console.log(`📧 Sending approval email to: ${currentBooking.email}`);
        const emailResult = await sendEmail(currentBooking.email, emailSubject, emailText, emailHtml);
        console.log(`✅ Approval email sent successfully to ${currentBooking.email}`);
        
        // Also log the deposit URL for debugging
        console.log(`🔗 Deposit URL generated: ${depositUrl}`);
        
      } catch (emailError) {
        console.error("❌ Error sending approval email:", emailError);
        console.error("❌ Email error details:", {
          to: currentBooking.email,
          subject: emailSubject,
          error: emailError instanceof Error ? emailError.message : String(emailError)
        });
        
        // Don't fail the entire request, but log the error
        // You might want to send this to an error tracking service
      }
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("❌ Error updating booking:", err);
    return NextResponse.json({ error: "Failed to update booking" }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;

    if (!ObjectId.isValid(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }

    const client = await clientPromise;
    const db = client.db("catsitting");

    const result = await db.collection("bookings").deleteOne({
      _id: new ObjectId(id),
    });

    if (result.deletedCount === 0) {
      return NextResponse.json({ error: "Booking not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("❌ Error deleting booking:", err);
    return NextResponse.json({ error: "Failed to delete booking" }, { status: 500 });
  }
}
