"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { 
  Calendar, 
  MessageSquare, 
  Clock,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  Users,
  MapPin,
  Star
} from "lucide-react";

interface Stats {
  messages: number;
  bookings: number;
  newBookings: number;
  revenue?: number;
}

interface Booking {
  _id: string;
  name: string;
  email: string;
  service: string;
  address: string;
  status: string;
  totalPrice: number;
  catCount: number;
  dates: string[];
  date?: string;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Color palette for different clients
  const clientColors = [
    'bg-blue-500',
    'bg-green-500', 
    'bg-purple-500',
    'bg-orange-500',
    'bg-pink-500',
    'bg-indigo-500',
    'bg-teal-500',
    'bg-red-500',
    'bg-yellow-500',
    'bg-cyan-500'
  ];

  // Fetch stats and bookings
  useEffect(() => {
    let isMounted = true;

    async function fetchData() {
      try {
        // Fetch stats
        const statsRes = await fetch("/api/admin/stats");
        if (statsRes.ok) {
          const statsData = await statsRes.json();
          if (isMounted) setStats(statsData);
        }

        // Fetch bookings for calendar
        const bookingsRes = await fetch("/api/admin/bookings?limit=100", {
          headers: {
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD || ""}`,
          },
        });
        if (bookingsRes.ok) {
          const bookingsData = await bookingsRes.json();
          if (isMounted) setBookings(bookingsData.bookings || []);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Calendar functions
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();
    
    return { daysInMonth, startingDayOfWeek };
  };

  const getBookingsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return bookings.filter(booking => {
      if (Array.isArray(booking.dates)) {
        return booking.dates.some((d: string) => d.startsWith(dateStr));
      }
      return booking.date && booking.date.startsWith(dateStr);
    });
  };

  const getClientColor = (clientName: string) => {
    const index = clientName.charCodeAt(0) % clientColors.length;
    return clientColors[index];
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'border-green-500';
      case 'pending': return 'border-yellow-500';
      case 'declined': return 'border-red-500';
      default: return 'border-gray-300';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-4 border-olive-200 border-t-olive-600 rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-warm-brown-800 to-warm-brown-900 text-white p-6 shadow-soft">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-3xl font-serif font-bold mb-2">📊 Admin Dashboard</h1>
            <p className="text-beige-200">Welcome back! Here's an overview of your cat sitting business.</p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-blue-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Total Bookings</p>
                <p className="text-2xl font-bold text-dark-gray-800">{stats?.bookings || 0}</p>
                <p className="text-blue-600 text-sm">All time</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Calendar className="text-blue-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-yellow-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Pending Bookings</p>
                <p className="text-2xl font-bold text-dark-gray-800">{stats?.newBookings || 0}</p>
                <p className="text-yellow-600 text-sm">Awaiting approval</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="text-yellow-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-green-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Total Messages</p>
                <p className="text-2xl font-bold text-dark-gray-800">{stats?.messages || 0}</p>
                <p className="text-green-600 text-sm">Customer inquiries</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <MessageSquare className="text-green-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-olive-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Revenue</p>
                <p className="text-2xl font-bold text-dark-gray-800">${stats?.revenue || 0}</p>
                <p className="text-olive-600 text-sm">Total earnings</p>
              </div>
              <div className="w-12 h-12 bg-olive-100 rounded-lg flex items-center justify-center">
                <DollarSign className="text-olive-600" size={24} />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Calendar Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="bg-white rounded-xl shadow-soft p-6 mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-serif font-bold text-dark-gray-800">📅 Booking Calendar</h2>
            <div className="flex items-center space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  const newDate = new Date(selectedDate);
                  newDate.setMonth(newDate.getMonth() - 1);
                  setSelectedDate(newDate);
                }}
                className="p-2 hover:bg-beige-100 rounded-lg transition-colors"
              >
                <ChevronLeft size={20} />
              </motion.button>
              <h3 className="text-xl font-semibold text-dark-gray-800">
                {selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h3>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  const newDate = new Date(selectedDate);
                  newDate.setMonth(newDate.getMonth() + 1);
                  setSelectedDate(newDate);
                }}
                className="p-2 hover:bg-beige-100 rounded-lg transition-colors"
              >
                <ChevronRight size={20} />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedDate(new Date())}
                className="px-4 py-2 bg-olive-600 text-white rounded-lg hover:bg-olive-700 transition-colors"
              >
                Today
              </motion.button>
            </div>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Day headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="p-3 text-center font-semibold text-dark-gray-600 bg-beige-100 rounded-lg">
                {day}
              </div>
            ))}

            {/* Calendar days */}
            {(() => {
              const { daysInMonth, startingDayOfWeek } = getDaysInMonth(selectedDate);
              const days = [];
              
              // Add empty cells for days before the first day of the month
              for (let i = 0; i < startingDayOfWeek; i++) {
                days.push(<div key={`empty-${i}`} className="p-3 min-h-[120px] bg-beige-50 rounded-lg" />);
              }
              
              // Add days of the month
              for (let day = 1; day <= daysInMonth; day++) {
                const date = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
                const dayBookings = getBookingsForDate(date);
                const isToday = date.toDateString() === new Date().toDateString();
                
                days.push(
                  <motion.div
                    key={day}
                    whileHover={{ scale: 1.02 }}
                    className={`p-3 min-h-[120px] rounded-lg border-2 transition-all ${
                      isToday 
                        ? 'border-olive-500 bg-olive-50' 
                        : 'border-beige-200 bg-white hover:border-olive-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`font-semibold ${isToday ? 'text-olive-700' : 'text-dark-gray-800'}`}>
                        {day}
                      </span>
                      {dayBookings.length > 0 && (
                        <span className="w-6 h-6 bg-olive-600 text-white text-xs rounded-full flex items-center justify-center">
                          {dayBookings.length}
                        </span>
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      {dayBookings.slice(0, 3).map((booking, index) => (
                                                 <motion.div
                           key={booking._id}
                           initial={{ opacity: 0, scale: 0.8 }}
                           animate={{ opacity: 1, scale: 1 }}
                           transition={{ delay: index * 0.1 }}
                           className={`p-2 rounded text-xs font-medium border-l-4 ${getStatusColor(booking.status)} ${
                             getClientColor(booking.name)
                           } bg-opacity-10 hover:bg-opacity-20 transition-all cursor-pointer`}
                         >
                           <div className="font-semibold truncate text-dark-gray-800">{booking.name}</div>
                           <div className="text-xs opacity-75 truncate">
                             {booking.service} • {booking.catCount || 1} cat{(booking.catCount || 1) > 1 ? 's' : ''}
                           </div>
                         </motion.div>
                      ))}
                      {dayBookings.length > 3 && (
                        <div className="text-xs text-dark-gray-500 text-center bg-beige-100 rounded px-2 py-1">
                          +{dayBookings.length - 3} more
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              }
              
              return days;
            })()}
          </div>

          {/* Legend */}
          <div className="mt-6 p-4 bg-beige-50 rounded-lg">
            <h4 className="font-semibold text-dark-gray-800 mb-3">Legend</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span className="text-sm text-dark-gray-600">Approved Bookings</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                <span className="text-sm text-dark-gray-600">Pending Bookings</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-red-500 rounded"></div>
                <span className="text-sm text-dark-gray-600">Declined Bookings</span>
              </div>
            </div>
            <p className="text-xs text-dark-gray-500 mt-2">
              Each client has a unique color for easy identification
            </p>
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="bg-white rounded-xl shadow-soft p-6 mb-8"
        >
          <h2 className="text-xl font-serif font-bold text-dark-gray-800 mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Link href="/admin/bookings" className="block">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg p-6 hover:from-blue-600 hover:to-blue-700 transition-all">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Manage Bookings</h3>
                      <p className="text-blue-100 text-sm">View and manage all bookings</p>
                    </div>
                    <Calendar className="text-blue-200" size={32} />
                  </div>
                </div>
              </Link>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Link href="/admin/messages" className="block">
                <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg p-6 hover:from-green-600 hover:to-green-700 transition-all">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">View Messages</h3>
                      <p className="text-green-100 text-sm">Check customer inquiries</p>
                    </div>
                    <MessageSquare className="text-green-200" size={32} />
                  </div>
                </div>
              </Link>
            </motion.div>
          </div>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="bg-white rounded-xl shadow-soft p-6"
        >
          <h2 className="text-xl font-serif font-bold text-dark-gray-800 mb-6">Recent Activity</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 bg-beige-50 rounded-lg">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Calendar className="text-blue-600" size={20} />
              </div>
              <div className="flex-1">
                <p className="font-medium text-dark-gray-800">New booking received</p>
                <p className="text-sm text-dark-gray-600">John Doe requested cat sitting for Dec 15</p>
              </div>
              <span className="text-xs text-dark-gray-500">2 hours ago</span>
            </div>

            <div className="flex items-center space-x-4 p-4 bg-beige-50 rounded-lg">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <MessageSquare className="text-green-600" size={20} />
              </div>
              <div className="flex-1">
                <p className="font-medium text-dark-gray-800">New message received</p>
                <p className="text-sm text-dark-gray-600">Sarah Smith inquired about weekend services</p>
              </div>
              <span className="text-xs text-dark-gray-500">4 hours ago</span>
            </div>

            <div className="flex items-center space-x-4 p-4 bg-beige-50 rounded-lg">
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                <Clock className="text-yellow-600" size={20} />
              </div>
              <div className="flex-1">
                <p className="font-medium text-dark-gray-800">Booking approved</p>
                <p className="text-sm text-dark-gray-600">Mike Johnson's booking for Dec 20 was approved</p>
              </div>
              <span className="text-xs text-dark-gray-500">1 day ago</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
