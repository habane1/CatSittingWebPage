"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { 
  MessageSquare, 
  Search, 
  X, 
  Eye, 
  EyeOff,
  Mail,
  User,
  Clock,
  ChevronLeft,
  ChevronRight,
  Filter
} from "lucide-react";

interface Message {
  _id: string;
  name: string;
  email: string;
  message: string;
  createdAt: string;
  status: "read" | "unread";
}

export default function AdminMessagesPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);

  // pagination
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const limit = 10; // messages per page

  useEffect(() => {
    async function fetchMessages() {
      setIsLoading(true);
      try {
        const res = await fetch(
          `/api/admin/messages?page=${page}&limit=${limit}`,
          {
            headers: {
              Authorization: `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD}`,
            },
          }
        );

        if (!res.ok) {
          console.error("Failed to fetch messages:", res.statusText);
          return;
        }

        const data = await res.json();
        setMessages(data.messages ?? []);
        setTotalPages(data.totalPages ?? 1);
      } catch (err) {
        console.error("Error fetching messages:", err);
      } finally {
        setIsLoading(false);
      }
    }
    fetchMessages();
  }, [page]);

  async function updateMessageStatus(id: string, status: "read" | "unread") {
    try {
      const res = await fetch(`/api/messages/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (res.ok) {
        setMessages((prev) =>
          prev.map((m) => (m._id === id ? { ...m, status } : m))
        );
      }
    } catch (err) {
      console.error("Failed to update message status:", err);
    }
  }

  // Apply filters
  const filteredMessages = messages.filter((msg) => {
    if (statusFilter !== "all" && msg.status !== statusFilter) return false;

    if (dateFilter !== "all") {
      const days = parseInt(dateFilter, 10);
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - days);

      const msgDate = new Date(msg.createdAt);
      if (msgDate < cutoff) return false;
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matches =
        msg.name?.toLowerCase().includes(q) ||
        msg.email?.toLowerCase().includes(q) ||
        msg.message?.toLowerCase().includes(q);
      if (!matches) return false;
    }

    return true;
  });

  function clearFilters() {
    setStatusFilter("all");
    setDateFilter("all");
    setSearchQuery("");
  }

  // Stats calculations
  const stats = {
    total: filteredMessages.length,
    unread: filteredMessages.filter(m => m.status === 'unread').length,
    read: filteredMessages.filter(m => m.status === 'read').length,
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-4 border-olive-200 border-t-olive-600 rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-warm-brown-800 to-warm-brown-900 text-white p-6 shadow-soft">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-serif font-bold mb-2">📩 Message Management</h1>
              <p className="text-beige-200">Manage all customer inquiries and messages</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-blue-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Total Messages</p>
                <p className="text-2xl font-bold text-dark-gray-800">{stats.total}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <MessageSquare className="text-blue-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-red-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Unread</p>
                <p className="text-2xl font-bold text-dark-gray-800">{stats.unread}</p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <EyeOff className="text-red-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            whileHover={{ y: -5 }}
            className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-green-500"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-dark-gray-600 text-sm">Read</p>
                <p className="text-2xl font-bold text-dark-gray-800">{stats.read}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Eye className="text-green-600" size={24} />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-soft p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-dark-gray-400" size={16} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search messages..."
                className="w-full pl-10 pr-4 py-2 border border-beige-300 rounded-lg focus:ring-2 focus:ring-olive-500 focus:border-transparent bg-beige-50"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 border border-beige-300 rounded-lg focus:ring-2 focus:ring-olive-500 focus:border-transparent bg-beige-50"
            >
              <option value="all">All Status</option>
              <option value="unread">Unread</option>
              <option value="read">Read</option>
            </select>

            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-4 py-2 border border-beige-300 rounded-lg focus:ring-2 focus:ring-olive-500 focus:border-transparent bg-beige-50"
            >
              <option value="all">All Dates</option>
              <option value="7">Last 7 Days</option>
              <option value="30">Last 30 Days</option>
              <option value="365">Last Year</option>
            </select>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={clearFilters}
              className="px-4 py-2 bg-dark-gray-600 text-white rounded-lg hover:bg-dark-gray-700 transition-colors flex items-center justify-center space-x-2"
            >
              <X size={16} />
              <span>Clear</span>
            </motion.button>
          </div>
        </div>

        {/* Messages */}
        <div className="space-y-4">
          {filteredMessages.length === 0 ? (
            <div className="bg-white rounded-xl shadow-soft p-12 text-center">
              <MessageSquare className="text-dark-gray-400 mx-auto mb-4" size={48} />
              <p className="text-dark-gray-600 text-lg">No messages match your filters.</p>
            </div>
          ) : (
            filteredMessages.map((msg, index) => (
              <motion.div
                key={msg._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-xl shadow-soft p-6 hover:shadow-medium transition-shadow ${
                  msg.status === "unread" ? "border-l-4 border-red-500" : ""
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      msg.status === "unread" ? "bg-red-100" : "bg-green-100"
                    }`}>
                      <User className={msg.status === "unread" ? "text-red-600" : "text-green-600"} size={20} />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-dark-gray-800 flex items-center space-x-2">
                        <span>{msg.name}</span>
                        {msg.status === "unread" && (
                          <span className="px-2 py-1 bg-red-100 text-red-600 text-xs rounded-full font-medium">
                            Unread
                          </span>
                        )}
                      </h3>
                      <p className="text-dark-gray-600 flex items-center space-x-2">
                        <Mail size={14} />
                        <a href={`mailto:${msg.email}`} className="text-olive-600 hover:text-olive-700">
                          {msg.email}
                        </a>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-dark-gray-500">
                    <Clock size={14} />
                    <span>{new Date(msg.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-dark-gray-700 leading-relaxed">{msg.message}</p>
                </div>

                <div className="flex justify-end">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() =>
                      updateMessageStatus(
                        msg._id,
                        msg.status === "read" ? "unread" : "read"
                      )
                    }
                    className={`px-4 py-2 rounded-lg text-white transition-colors flex items-center space-x-2 ${
                      msg.status === "read" 
                        ? "bg-orange-600 hover:bg-orange-700" 
                        : "bg-green-600 hover:bg-green-700"
                    }`}
                  >
                    {msg.status === "read" ? (
                      <>
                        <EyeOff size={16} />
                        <span>Mark as Unread</span>
                      </>
                    ) : (
                      <>
                        <Eye size={16} />
                        <span>Mark as Read</span>
                      </>
                    )}
                  </motion.button>
                </div>
              </motion.div>
            ))
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center space-x-4 mt-8">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-4 py-2 bg-white border border-beige-300 rounded-lg hover:bg-beige-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              <ChevronLeft size={16} />
              <span>Previous</span>
            </motion.button>
            <span className="text-dark-gray-600">
              Page {page} of {totalPages}
            </span>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-4 py-2 bg-white border border-beige-300 rounded-lg hover:bg-beige-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              <span>Next</span>
              <ChevronRight size={16} />
            </motion.button>
          </div>
        )}
      </div>
    </div>
  );
}
