"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Calendar, 
  Search, 
  Filter, 
  X, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Eye,
  Edit,
  Trash2,
  Download,
  RefreshCw,
  CalendarDays,
  Users,
  DollarSign,
  MapPin,
  Mail,
  Phone,
  Star,
  TrendingUp,
  BarChart3
} from "lucide-react";

export default function AdminBookingsPage() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [viewMode, setViewMode] = useState<"list" | "stats">("list");

  const [isLoading, setIsLoading] = useState(true);

  // Pagination
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const limit = 10;

  useEffect(() => {
    async function fetchBookings() {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/admin/bookings?page=${page}&limit=${limit}`, {
          headers: {
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD || ""}`,
          },
        });

        if (!res.ok) {
          console.error("Failed to fetch bookings:", res.status, res.statusText);
          setBookings([]);
          setTotalPages(1);
          return;
        }

        const data = await res.json().catch(() => null);
        setBookings(data?.bookings ?? []);
        setTotalPages(data?.totalPages ?? 1);
      } catch (error) {
        console.error("Error fetching bookings:", error);
        setBookings([]);
        setTotalPages(1);
      } finally {
        setIsLoading(false);
      }
    }
    fetchBookings();
  }, [page]);

  async function updateBooking(id: string, status: string) {
    try {
      const res = await fetch(`/api/bookings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (res.ok) {
        setBookings((prev) =>
          prev.map((b) => (b._id === id ? { ...b, status } : b))
        );
      } else {
        console.error("Failed to update booking");
      }
    } catch (error) {
      console.error("Error updating booking:", error);
    }
  }

  async function checkExpiredDeposits() {
    try {
      const res = await fetch("/api/admin/check-expired-deposits", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.NEXT_PUBLIC_ADMIN_PASSWORD || ""}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        alert(`Checked expired deposits: ${data.message}`);
        window.location.reload();
      } else {
        console.error("Failed to check expired deposits");
        alert("Failed to check expired deposits");
      }
    } catch (error) {
      console.error("Error checking expired deposits:", error);
      alert("Error checking expired deposits");
    }
  }

  // Apply filters
  const filteredBookings = bookings.filter((b) => {
    if (statusFilter !== "all" && b.status !== statusFilter) return false;

    if (dateFilter !== "all") {
      const days = parseInt(dateFilter, 10);
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - days);

      if (Array.isArray(b.dates) && b.dates.length) {
        const hasValidDate = b.dates.some((d: string) => new Date(d) >= cutoff);
        if (!hasValidDate) return false;
      } else if (b.date && new Date(b.date) < cutoff) {
        return false;
      }
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matches =
        b.name?.toLowerCase().includes(q) ||
        b.email?.toLowerCase().includes(q) ||
        b.address?.toLowerCase().includes(q) ||
        b.service?.toLowerCase().includes(q) ||
        b.instructions?.toLowerCase().includes(q) ||
        b.notes?.toLowerCase().includes(q);
      if (!matches) return false;
    }

    return true;
  });

  function clearFilters() {
    setStatusFilter("all");
    setDateFilter("all");
    setSearchQuery("");
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'declined': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getDepositStatus = (booking: any) => {
    if (!booking.deposit) return null;
    
    const now = new Date();
    const deadline = new Date(booking.deposit.deadline);
    const timeLeft = deadline.getTime() - now.getTime();
    const hoursLeft = Math.floor(timeLeft / (1000 * 60 * 60));
    
    if (booking.deposit.status === "paid") {
      return { status: "paid", text: "Paid", color: "text-green-600", bg: "bg-green-50" };
    } else if (timeLeft <= 0) {
      return { status: "expired", text: "Expired", color: "text-red-600", bg: "bg-red-50" };
    } else if (hoursLeft <= 2) {
      return { status: "urgent", text: `${hoursLeft}h left`, color: "text-orange-600", bg: "bg-orange-50" };
    } else {
      return { status: "pending", text: `${hoursLeft}h left`, color: "text-blue-600", bg: "bg-blue-50" };
    }
  };

  // Stats calculations
  const stats = {
    total: filteredBookings.length,
    pending: filteredBookings.filter(b => b.status === 'pending').length,
    approved: filteredBookings.filter(b => b.status === 'approved').length,
    declined: filteredBookings.filter(b => b.status === 'declined').length,
    revenue: filteredBookings
      .filter(b => b.status === 'approved')
      .reduce((sum, b) => sum + (b.totalPrice || 0), 0)
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-beige-50 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-4 border-olive-200 border-t-olive-600 rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-beige-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-warm-brown-800 to-warm-brown-900 text-white p-6 shadow-soft">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-serif font-bold mb-2">📋 Booking Management</h1>
              <p className="text-beige-200">Manage all your cat sitting bookings</p>
            </div>
            <div className="flex items-center space-x-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={checkExpiredDeposits}
                className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
              >
                <Clock size={16} />
                <span>Check Deposits</span>
              </motion.button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* View Mode Toggle */}
        <div className="bg-white rounded-xl shadow-soft p-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex space-x-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setViewMode("list")}
                className={`px-4 py-2 rounded-lg flex items-center space-x-2 transition-all ${
                  viewMode === "list" 
                    ? "bg-olive-600 text-white" 
                    : "bg-beige-100 text-dark-gray-700 hover:bg-beige-200"
                }`}
              >
                <BarChart3 size={16} />
                <span>List View</span>
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setViewMode("stats")}
                className={`px-4 py-2 rounded-lg flex items-center space-x-2 transition-all ${
                  viewMode === "stats" 
                    ? "bg-olive-600 text-white" 
                    : "bg-beige-100 text-dark-gray-700 hover:bg-beige-200"
                }`}
              >
                <TrendingUp size={16} />
                <span>Analytics</span>
              </motion.button>
            </div>
            <div className="text-sm text-dark-gray-600">
              {filteredBookings.length} bookings found
            </div>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-dark-gray-400" size={16} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search bookings..."
                className="w-full pl-10 pr-4 py-2 border border-beige-300 rounded-lg focus:ring-2 focus:ring-olive-500 focus:border-transparent bg-beige-50"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 border border-beige-300 rounded-lg focus:ring-2 focus:ring-olive-500 focus:border-transparent bg-beige-50"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="declined">Declined</option>
            </select>

            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-4 py-2 border border-beige-300 rounded-lg focus:ring-2 focus:ring-olive-500 focus:border-transparent bg-beige-50"
            >
              <option value="all">All Dates</option>
              <option value="7">Last 7 Days</option>
              <option value="30">Last 30 Days</option>
              <option value="365">Last Year</option>
            </select>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={clearFilters}
              className="px-4 py-2 bg-dark-gray-600 text-white rounded-lg hover:bg-dark-gray-700 transition-colors flex items-center justify-center space-x-2"
            >
              <X size={16} />
              <span>Clear</span>
            </motion.button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {viewMode === "list" && (
            <motion.div
              key="list"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-blue-500"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-dark-gray-600 text-sm">Total Bookings</p>
                      <p className="text-2xl font-bold text-dark-gray-800">{stats.total}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <CalendarDays className="text-blue-600" size={24} />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-yellow-500"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-dark-gray-600 text-sm">Pending</p>
                      <p className="text-2xl font-bold text-dark-gray-800">{stats.pending}</p>
                    </div>
                    <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Clock className="text-yellow-600" size={24} />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-green-500"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-dark-gray-600 text-sm">Approved</p>
                      <p className="text-2xl font-bold text-dark-gray-800">{stats.approved}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <CheckCircle className="text-green-600" size={24} />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-xl shadow-soft p-6 border-l-4 border-olive-500"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-dark-gray-600 text-sm">Revenue</p>
                      <p className="text-2xl font-bold text-dark-gray-800">${stats.revenue}</p>
                    </div>
                    <div className="w-12 h-12 bg-olive-100 rounded-lg flex items-center justify-center">
                      <DollarSign className="text-olive-600" size={24} />
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Booking Cards */}
              <div className="space-y-4">
                {filteredBookings.map((booking, index) => (
                  <motion.div
                    key={booking._id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white rounded-xl shadow-soft p-6 hover:shadow-medium transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-olive-100 rounded-full flex items-center justify-center">
                          <Users className="text-olive-600" size={20} />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-dark-gray-800">{booking.name}</h3>
                          <p className="text-dark-gray-600 flex items-center space-x-2">
                            <Mail size={14} />
                            <span>{booking.email}</span>
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(booking.status)}`}>
                          {booking.status}
                        </span>
                        {getDepositStatus(booking) && (
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDepositStatus(booking)?.bg} ${getDepositStatus(booking)?.color}`}>
                            {getDepositStatus(booking)?.text}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                      <div className="flex items-center space-x-2">
                        <MapPin className="text-dark-gray-400" size={16} />
                        <span className="text-dark-gray-700">{booking.address || "N/A"}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Star className="text-dark-gray-400" size={16} />
                        <span className="text-dark-gray-700">{booking.service || "N/A"}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users className="text-dark-gray-400" size={16} />
                        <span className="text-dark-gray-700">{booking.catCount || "N/A"} cat{(booking.catCount || 0) > 1 ? 's' : ''}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <DollarSign className="text-dark-gray-400" size={16} />
                        <span className="text-dark-gray-700">${booking.totalPrice || "N/A"}</span>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-dark-gray-700">
                        <strong>Dates:</strong>{" "}
                        {Array.isArray(booking.dates) && booking.dates.length > 0
                          ? booking.dates.map((d: string, i: number) => (
                              <span key={i} className="inline-block bg-beige-100 px-2 py-1 rounded mr-2 mb-1">
                                {new Date(d).toLocaleDateString()}
                              </span>
                            ))
                          : booking.date
                          ? <span className="inline-block bg-beige-100 px-2 py-1 rounded">{new Date(booking.date).toLocaleDateString()}</span>
                          : "N/A"}
                      </p>
                    </div>

                    {booking.instructions && (
                      <div className="mb-4">
                        <p className="text-dark-gray-700">
                          <strong>Instructions:</strong> {booking.instructions}
                        </p>
                      </div>
                    )}

                    {booking.notes && (
                      <div className="mb-4">
                        <p className="text-dark-gray-700">
                          <strong>Notes:</strong> {booking.notes}
                        </p>
                      </div>
                    )}

                    {/* Deposit Information */}
                    {booking.deposit && (
                      <div className="bg-beige-50 rounded-lg p-4 mb-4">
                        <h4 className="font-semibold text-dark-gray-800 mb-2">Payment Details</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-dark-gray-600">Deposit:</span>
                            <span className="ml-2 font-medium">${booking.deposit.amount}</span>
                          </div>
                          <div>
                            <span className="text-dark-gray-600">Total:</span>
                            <span className="ml-2 font-medium">${booking.deposit.total}</span>
                          </div>
                          {booking.deposit.deadline && (
                            <div>
                              <span className="text-dark-gray-600">Deadline:</span>
                              <span className="ml-2 font-medium">{new Date(booking.deposit.deadline).toLocaleString()}</span>
                            </div>
                          )}
                        </div>
                        {booking.status === "approved" && booking.deposit.status === "pending" && (
                          <div className="mt-3">
                            <a 
                              href={booking.deposit.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-olive-600 hover:text-olive-700 text-sm font-medium"
                            >
                              View Payment Page →
                            </a>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-between">
                      <div className="flex space-x-2">
                        {booking.status === "pending" && (
                          <>
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => updateBooking(booking._id, "approved")}
                              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                            >
                              <CheckCircle size={16} />
                              <span>Approve</span>
                            </motion.button>
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => updateBooking(booking._id, "declined")}
                              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
                            >
                              <XCircle size={16} />
                              <span>Decline</span>
                            </motion.button>
                          </>
                        )}
                      </div>
                      <div className="flex space-x-2">
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="p-2 text-dark-gray-400 hover:text-dark-gray-600 hover:bg-beige-100 rounded-lg transition-colors"
                        >
                          <Eye size={16} />
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="p-2 text-dark-gray-400 hover:text-dark-gray-600 hover:bg-beige-100 rounded-lg transition-colors"
                        >
                          <Edit size={16} />
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center space-x-4 mt-8">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                    className="px-4 py-2 bg-white border border-beige-300 rounded-lg hover:bg-beige-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                  >
                    <ChevronLeft size={16} />
                    <span>Previous</span>
                  </motion.button>
                  <span className="text-dark-gray-600">
                    Page {page} of {totalPages}
                  </span>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                    className="px-4 py-2 bg-white border border-beige-300 rounded-lg hover:bg-beige-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                  >
                    <span>Next</span>
                    <ChevronRight size={16} />
                  </motion.button>
                </div>
              )}
            </motion.div>
          )}

          {viewMode === "stats" && (
            <motion.div
              key="stats"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              {/* Enhanced Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl shadow-soft p-6"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-100 text-sm">Total Bookings</p>
                      <p className="text-3xl font-bold">{stats.total}</p>
                      <p className="text-blue-200 text-sm">All time</p>
                    </div>
                    <div className="w-16 h-16 bg-blue-400 bg-opacity-30 rounded-full flex items-center justify-center">
                      <CalendarDays size={32} />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white rounded-xl shadow-soft p-6"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-yellow-100 text-sm">Pending</p>
                      <p className="text-3xl font-bold">{stats.pending}</p>
                      <p className="text-yellow-200 text-sm">Awaiting approval</p>
                    </div>
                    <div className="w-16 h-16 bg-yellow-400 bg-opacity-30 rounded-full flex items-center justify-center">
                      <Clock size={32} />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-xl shadow-soft p-6"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-100 text-sm">Approved</p>
                      <p className="text-3xl font-bold">{stats.approved}</p>
                      <p className="text-green-200 text-sm">Confirmed bookings</p>
                    </div>
                    <div className="w-16 h-16 bg-green-400 bg-opacity-30 rounded-full flex items-center justify-center">
                      <CheckCircle size={32} />
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-gradient-to-br from-olive-500 to-olive-600 text-white rounded-xl shadow-soft p-6"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-olive-100 text-sm">Revenue</p>
                      <p className="text-3xl font-bold">${stats.revenue}</p>
                      <p className="text-olive-200 text-sm">Total earnings</p>
                    </div>
                    <div className="w-16 h-16 bg-olive-400 bg-opacity-30 rounded-full flex items-center justify-center">
                      <DollarSign size={32} />
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Charts Placeholder */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl shadow-soft p-6">
                  <h3 className="text-lg font-semibold text-dark-gray-800 mb-4">Booking Trends</h3>
                  <div className="h-64 bg-beige-50 rounded-lg flex items-center justify-center">
                    <p className="text-dark-gray-500">Chart visualization coming soon</p>
                  </div>
                </div>
                
                <div className="bg-white rounded-xl shadow-soft p-6">
                  <h3 className="text-lg font-semibold text-dark-gray-800 mb-4">Service Distribution</h3>
                  <div className="h-64 bg-beige-50 rounded-lg flex items-center justify-center">
                    <p className="text-dark-gray-500">Chart visualization coming soon</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
